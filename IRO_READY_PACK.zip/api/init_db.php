<?php
$db = new PDO('sqlite:../iro.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("
CREATE TABLE IF NOT EXISTS incidents (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 reference TEXT UNIQUE NOT NULL,
 entite TEXT NOT NULL,
 declarant TEXT NOT NULL,
 email_declarant TEXT,
 date_survenance DATE NOT NULL,
 date_constatation DATE NOT NULL,
 date_declaration DATE NOT NULL,
 statut TEXT NOT NULL,
 nature TEXT NOT NULL,
 description TEXT NOT NULL,
 type_evenement TEXT NOT NULL,
 impacts TEXT,
 montant_perte REAL DEFAULT 0,
 montant_recuperable REAL DEFAULT 0,
 impact_qualitatif TEXT,
 causes TEXT,
 actions TEXT,
 cro TEXT,
 dro TEXT,
 observations TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME
);
");
echo "DB OK";
