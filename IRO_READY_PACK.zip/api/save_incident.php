<?php
require 'db.php';
$data = json_decode(file_get_contents("php://input"), true);
$stmt = $db->prepare("INSERT INTO incidents(reference,entite,declarant,email_declarant,date_survenance,date_constatation,date_declaration,statut,nature,description,type_evenement,impacts,montant_perte,montant_recuperable,impact_qualitatif,causes,actions,cro,dro,observations)
VALUES(:reference,:entite,:declarant,:email,:ds,:dc,:dd,:statut,:nature,:description,:type,:impacts,:perte,:recup,:impactq,:causes,:actions,:cro,:dro,:obs)");
$stmt->execute([
':reference'=>$data['reference'],
':entite'=>$data['entite'],
':declarant'=>$data['declarant'],
':email'=>$data['emailDeclarant'],
':ds'=>$data['dateSurvenance'],
':dc'=>$data['dateConstatation'],
':dd'=>$data['dateDeclaration'],
':statut'=>$data['statut'],
':nature'=>$data['nature'],
':description'=>$data['description'],
':type'=>$data['typeEvenement'],
':impacts'=>$data['impacts'],
':perte'=>$data['montantPerte'],
':recup'=>$data['montantRecuperable'],
':impactq'=>$data['impactQualitatif'],
':causes'=>$data['causes'],
':actions'=>$data['actions'],
':cro'=>$data['cro'],
':dro'=>$data['dro'],
':obs'=>$data['observations']
]);
echo json_encode(['success'=>true]);
